import xbmcgui, xbmc
dialog = xbmcgui.Dialog()
dialog.notification("AS Cleaner", "Cleaning cache and temp files...", xbmcgui.NOTIFICATION_INFO, 3000)
# Simulated cleaning action
xbmc.sleep(2000)
dialog.notification("AS Cleaner", "Cleaning complete!", xbmcgui.NOTIFICATION_INFO, 3000)
