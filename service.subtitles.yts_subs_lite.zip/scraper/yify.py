# Dummy scraper for YTS subs lite
def search(params):
    return []

def download(params):
    return {}
