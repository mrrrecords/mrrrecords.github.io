# Common utilities
